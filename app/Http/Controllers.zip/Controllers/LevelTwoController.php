<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Http\Requests\StoreLevel_TwoRequest;
use App\Http\Requests\UpdateLevel_TwoRequest;
use App\Models\Level_Two;
use App\Models\Subcategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Twilio\TwiML\Voice\Leave;

class LevelTwoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $alllevel_two = Level_Two::where('added_from', session()->get('user_added'))->latest()->get();
        $array_data = [];
        $array_category = [];
        foreach ($alllevel_two as $level_two) {
            $subcatname = Subcategory::where('id', $level_two->subcategory)->first();
            if (!empty($subcatname)) {
                $array_data[$subcatname->id] = $subcatname;
            } else {
                continue;
            }
        }
        foreach ($array_data as $key => $data) {
            $category = Category::where('id', $key)->first();
            if (!empty($category)) {
                $array_category[$key] = $category;
            } else {
                continue;
            }
        }
        $compact = compact("alllevel_two", "array_data", "array_category");
        return view('LevelTwo.view')->with($compact);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $user = DB::table('users')->where("id", session()->get('user_added'))->first();
        $allsubcategory = Subcategory::where('added_from', session()->get('user_added'))->where('subcategory_status', 1)->latest()->get();
        return view('LevelTwo.add', compact("user", "allsubcategory"));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreLevel_TwoRequest $request)
    {
        $input = $request->all();
        $input['level_two_title'] = strtolower($request->level_two_title);
        $input['added_from'] = session()->get('user_added');
        $input['level_two_status'] = 1;
        Level_Two::create($input);
        return response()->json([
            "message" => 200,
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $level_two = Level_Two::where('id', $id)->first();
        $status = $level_two->level_two_status;
        if ($status == 1) {
            Level_Two::where('id', $level_two->id)->update([
                "level_two_status" => 2,
            ]);
        } else {
            Level_Two::where('id', $level_two->id)->update([
                "level_two_status" => 1,
            ]);
        }
        return response()->json([
            "message" => $level_two,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return response()->json([
            "message" => Level_Two::where('id', $id)->first(),
            "allsubcategory" => Subcategory::where('added_from', session()->get('user_added'))->where('subcategory_status', 1)->latest()->get(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $level_two = Level_Two::where('id', $id)->first();
        $request->validate(
            [
                "level_two_title" => "unique:level__twos,level_two_title,$level_two->id",
            ]
        );
        $input = $request->all();
        $input['level_two_title'] = strtolower($request->level_two_title);
        $input['added_from'] = session()->get('user_added');
        $input['level_two_status'] = $level_two->level_two_status;
        $level_two->update($input);
        return response()->json([
            "module" => "degree",
            "module_data" => $level_two,
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        Level_Two::where('id', $id)->delete();
        return response()->json([
            "message" => 200,
        ]);
    }
}
