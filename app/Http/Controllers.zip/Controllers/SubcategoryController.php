<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Http\Requests\StoreSubcategoryRequest;
use App\Http\Requests\UpdateSubcategoryRequest;
use App\Models\Subcategory;
use Illuminate\Support\Facades\DB;

class SubcategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $allsubcategory = Subcategory::where('added_from', session()->get('user_added'))->latest()->get();
        $array_data = [];
        foreach ($allsubcategory as $subcategory) {
            $catname = Category::where('id', $subcategory->category)->first();
            if (!empty($catname)) {
                $array_data[$catname->id] = $catname->category_title;
            }else {
                continue;
            }
        }
        $compact = compact("allsubcategory", "array_data");
        return view('Subcategory.view')->with($compact);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $user = DB::table('users')->where("id", session()->get('user_added'))->first();
        $allcategory = Category::where('added_from', session()->get('user_added'))->where('category_status', 1)->latest()->get();
        return view('Subcategory.add', compact("user", "allcategory"));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreSubcategoryRequest $request)
    {
        $input = $request->all();
        $input['subcategory_title'] = strtolower($request->subcategory_title);
        $input['added_from'] = session()->get('user_added');
        $input['subcategory_status'] = 1;
        Subcategory::create($input);
        return response()->json([
            "message" => 200,
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show(Subcategory $subcategory)
    {
        $status = $subcategory->subcategory_status;
        if ($status == 1) {
            Subcategory::where('id', $subcategory->id)->update([
                "subcategory_status" => 2,
            ]);
        } else {
            Subcategory::where('id', $subcategory->id)->update([
                "subcategory_status" => 1,
            ]);
        }
        return response()->json([
            "message" => $subcategory,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Subcategory $subcategory)
    {
        return response()->json([
            "message" => $subcategory,
            "allcategory" => Category::where('added_from', session()->get('user_added'))->where('category_status', 1)->latest()->get(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateSubcategoryRequest $request, Subcategory $subcategory)
    {
        $request->validate(
            [
                "subcategory_title" => "unique:subcategories,subcategory_title,$subcategory->id",
            ]
        );
        $input = $request->all();
        $input['subcategory_title'] = strtolower($request->subcategory_title);
        $input['added_from'] = session()->get('user_added');
        $input['subcategory_status'] = $subcategory->subcategory_status;
        $subcategory->update($input);
        return response()->json([
            "module" => "degree",
            "module_data" => $subcategory,
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Subcategory $subcategory)
    {
        $subcategory->delete();
        return response()->json([
            "message" => 200,
        ]);
    }
}
