<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Http\Requests\StoreCategoryRequest;
use App\Http\Requests\UpdateCategoryRequest;
use Illuminate\Support\Facades\DB;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $allcategory = Category::where('added_from', session()->get('user_added'))->latest()->get();
        $compact = compact("allcategory");
        return view('Category.view')->with($compact);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $user = DB::table('users')->where("id", session()->get('user_added'))->first();
        return view('Category.add', compact("user"));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreCategoryRequest $request)
    {
        $input = $request->all();
        $input['category_title'] = strtolower($request->category_title);
        $input['added_from'] = session()->get('user_added');
        $input['category_status'] = 1;
        Category::create($input);
        return response()->json([
            "message" => 200,
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show(Category $category)
    {
        $status = $category->category_status;
        if ($status == 1) {
            Category::where('id', $category->id)->update([
                "category_status" => 2,
            ]);
        } else {
            Category::where('id', $category->id)->update([
                "category_status" => 1,
            ]);
        }
        return response()->json([
            "message" => $category,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Category $category)
    {
        return response()->json([
            "message" => $category,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCategoryRequest $request, Category $category)
    {
        $request->validate(
            [
                "category_title" => "unique:categories,category_title,$category->id",
            ]
        );
        $input = $request->all();
        $input['category_title'] = strtolower($request->category_title);
        $input['added_from'] = session()->get('user_added');
        $input['category_status'] = $category->category_status;
        $category->update($input);
        return response()->json([
            "module" => "degree",
            "module_data" => $category,
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Category $category)
    {
        $category->delete();
        return response()->json([
            "message" => 200,
        ]);
    }
}
